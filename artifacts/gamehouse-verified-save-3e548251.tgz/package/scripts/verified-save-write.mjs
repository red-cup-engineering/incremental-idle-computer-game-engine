/** The synchronous write/readback step shared by browser game save adapters.
 * Callers own their key, preflight comparison, locking, save admission, recovery
 * and UI policy. A successful readback is an observation, not a durability or
 * compare-and-swap guarantee. Callbacks must be synchronous; no retries or
 * rollback are performed, including when a write throws after changing storage.
 */
export function writeVerifiedSave({ read, write, text } = {}) {
  if (typeof read !== 'function' || typeof write !== 'function' || typeof text !== 'string') {
    throw new TypeError('writeVerifiedSave requires synchronous read/write functions and save text');
  }
  try {
    write(text);
  } catch (error) {
    return { ok: false, kind: 'write-error', error };
  }
  let actual;
  try {
    actual = read();
  } catch (error) {
    return { ok: false, kind: 'read-error', error };
  }
  return actual === text ? { ok: true } : { ok: false, kind: 'mismatch', actual };
}
